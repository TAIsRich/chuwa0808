package com.chuwa.redbook2;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Redbook2ApplicationTests {

	@Test
	void contextLoads() {
	}

}
