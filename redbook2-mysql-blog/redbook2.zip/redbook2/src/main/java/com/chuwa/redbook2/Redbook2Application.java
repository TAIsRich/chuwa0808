package com.chuwa.redbook2;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Redbook2Application {

	public static void main(String[] args) {
		SpringApplication.run(Redbook2Application.class, args);
	}

}
