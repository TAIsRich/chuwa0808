package com.chuwa.CassandraBlog;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CassandraBlogApplicationTests {

	@Test
	void contextLoads() {
	}

}
