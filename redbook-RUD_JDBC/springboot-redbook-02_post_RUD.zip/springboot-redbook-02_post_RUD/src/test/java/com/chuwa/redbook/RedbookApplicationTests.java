package com.chuwa.redbook;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RedbookApplicationTests {

	@Test
	void contextLoads() {
	}

}
