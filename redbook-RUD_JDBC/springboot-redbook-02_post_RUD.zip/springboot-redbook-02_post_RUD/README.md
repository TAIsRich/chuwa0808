In this branch, you need to learn; 
* in PostServiceImpl, define 2 private methods.
   * mapToEntity
   * mapToDTO
* add package exception
  * ResourceNotFoundException
* add RUD operations in service layer and controller layer.

**Use Postman to call each API to check the response.**