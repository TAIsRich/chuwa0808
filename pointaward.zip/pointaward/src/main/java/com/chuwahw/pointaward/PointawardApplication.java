package com.chuwahw.pointaward;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PointawardApplication {

	public static void main(String[] args) {
		SpringApplication.run(PointawardApplication.class, args);
	}

}
